# BioRLHF: LLM Training on KMP Mouse Multi-Tissue Data

Train a language model to reason about biological interactions using your unique 2×2×2 factorial KMP dataset.

## 🎯 Project Overview

**Goal**: Fine-tune an LLM on biological reasoning tasks using your kaempferol spaceflight countermeasure data.

**Dataset**: 200 instruction-tuning examples covering:
- Factual recall (DEG counts, pathway patterns)
- Comparison questions (tissue differences)
- Interaction prediction (drug×stressor effects)
- Experimental design critique
- Mechanistic reasoning
- Uncertainty calibration

## 📁 Files Included

```
biorlhf/
├── README.md                    # This file
├── requirements.txt             # Python dependencies
├── setup_cayuga.sh             # One-time setup script
├── run_sft.sh                  # SLURM job submission script
├── sft_train.py                # Main training script
├── kmp_sft_dataset.json        # 200 training examples
├── create_sft_dataset.py       # Dataset generation script
└── create_expanded_sft_dataset.py  # Extended dataset generator
```

## 🚀 Quick Start (Cayuga HPC)

### Step 1: Upload files to Cayuga

```bash
# From your local machine
scp -r biorlhf/ <netid>@cayuga.cac.cornell.edu:~/
```

### Step 2: Set up environment (one time only)

```bash
# SSH to Cayuga
ssh <netid>@cayuga.cac.cornell.edu

# Navigate to project directory
cd ~/biorlhf

# Run setup script
chmod +x setup_cayuga.sh
./setup_cayuga.sh

# Login to Weights & Biases (for training monitoring)
wandb login

# Login to Hugging Face (for model access)
huggingface-cli login
```

### Step 3: Submit training job

```bash
# Make sure you're in the biorlhf directory
cd ~/biorlhf

# Activate environment
conda activate biorlhf

# Submit job
sbatch run_sft.sh

# Check job status
squeue -u $USER

# Monitor training (once job starts)
tail -f logs/sft_<jobid>.log
```

### Step 4: Monitor on Weights & Biases

Go to https://wandb.ai to see training curves in real-time.

## 📊 Expected Training Time

| Configuration | Time | GPU Memory |
|---------------|------|------------|
| Mistral-7B, 4-bit, LoRA | ~2-4 hours | ~20GB |
| Llama-3-8B, 4-bit, LoRA | ~3-5 hours | ~24GB |

## 🔧 Customization Options

### Change base model

Edit `run_sft.sh`:
```bash
python sft_train.py \
    --model "meta-llama/Meta-Llama-3.1-8B"  # or other model
```

### Adjust training hyperparameters

```bash
python sft_train.py \
    --epochs 5 \          # More epochs
    --batch_size 2 \      # Smaller batch if OOM
    --lr 1e-4 \           # Different learning rate
    --lora_r 64           # Larger LoRA rank
```

### Run without Weights & Biases

```bash
python sft_train.py --no_wandb
```

## 📈 What to Expect

### Training loss curve
- Should decrease steadily over epochs
- Final loss typically 0.5-1.5 for this dataset size

### Evaluation loss
- Should follow training loss
- Significant gap indicates overfitting

### After training
- Model saved to `./kmp_sft_model/`
- LoRA adapters in `./kmp_sft_model/lora_adapters/`

## 🧪 Testing the Model

After training completes:

```python
from transformers import AutoModelForCausalLM, AutoTokenizer
from peft import PeftModel

# Load base model
base_model = AutoModelForCausalLM.from_pretrained(
    "mistralai/Mistral-7B-v0.3",
    torch_dtype=torch.bfloat16,
    device_map="auto",
)

# Load fine-tuned LoRA adapters
model = PeftModel.from_pretrained(
    base_model,
    "./kmp_sft_model/lora_adapters"
)

tokenizer = AutoTokenizer.from_pretrained("./kmp_sft_model")

# Test generation
prompt = """### Instruction:
What is the KMP response type for soleus muscle?

### Response:
"""

inputs = tokenizer(prompt, return_tensors="pt").to("cuda")
outputs = model.generate(**inputs, max_new_tokens=200)
print(tokenizer.decode(outputs[0]))
```

## 🔜 Next Steps (Week 2: DPO)

After SFT training, proceed to DPO preference learning:

1. Create preference dataset (chosen vs rejected responses)
2. Run DPO training on SFT model
3. Evaluate on held-out test set

See `BioRLHF_KMP_Project_Plan.md` for full 4-week roadmap.

## 📝 Dataset Statistics

```
Total examples: 200
Average length: 426 characters

Categories (approximate):
- Factual: 72 (36%)
- Comparison: 14 (7%)
- Prediction: 17 (8.5%)
- Critique: 5 (2.5%)
- Mechanistic: 4 (2%)
- Calibration: 8 (4%)
- Other: 80 (40%)
```

## 🐛 Troubleshooting

### CUDA out of memory
- Reduce batch_size to 2 or 1
- Increase gradient_accumulation_steps proportionally
- Use smaller model (7B instead of 8B)

### Job timeout
- Request more time: `#SBATCH --time=24:00:00`
- Reduce epochs and resume later

### Module not found
- Ensure conda environment is activated
- Re-run setup script

### wandb errors
- Run `wandb login` again
- Or use `--no_wandb` flag

## 📚 References

- [TRL Documentation](https://huggingface.co/docs/trl)
- [PEFT Documentation](https://huggingface.co/docs/peft)
- [LoRA Paper](https://arxiv.org/abs/2106.09685)
- [SFT Best Practices](https://huggingface.co/docs/trl/sft_trainer)

## ✅ Success Checklist

- [ ] Environment set up on Cayuga
- [ ] Logged into wandb and HuggingFace
- [ ] Training job submitted
- [ ] Training loss decreasing
- [ ] Model saved successfully
- [ ] Test generation works

---

**Questions?** Check the logs in `logs/` directory or the Weights & Biases dashboard.
